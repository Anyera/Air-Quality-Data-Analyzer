clear
clc
%%%%Reading in the csv files for Data
Temp_Humidity_files=dir('dht22*.csv');
Air_Files=dir('201*.csv');
DHT22_data = [];
SDS_Data = [];
for count = 1:length(Air_Files);
   FileName = Air_Files(count).name
   SDSData = dlmread(FileName);
   SDS_Data = [SDS_Data;SDSData];
   SDS_Data = flip(SDS_Data);
end    

for count = 1:length(Temp_Humidity_files);
    FileName = Temp_Humidity_files(count).name
    TempData = csvread(FileName);
    TempData = TempData(2:end,:);
    DHT22_data = [DHT22_data;TempData];
    DHT22_data = flip(DHT22_data);
end 

A=length(DHT22_data);
%%%%%Temperature and Humidity
     disp("Temperature")
     minimum_Temperature = min(DHT22_data(:,2))
     maximum_Temperature =max(DHT22_data(:,2))
     Average_Temperature = mean(DHT22_data(:,2))
     Std_Dev_Temperature = std(DHT22_data(:,2))
     disp("Humidity")    
     minimum_Humidity = min(DHT22_data(:,3))
     maximum_Humidity = max(DHT22_data(:,3))
     Average_humidity = mean(DHT22_data(:,3))
     Std_Dev_Humidity = std(DHT22_data(:,3))
     
%%%%%%Correaltion between Temperature and Humidity     
     Corr_Temp_Humidity = corr(DHT22_data(:,2),DHT22_data(:,3))
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
if length(SDS_Data)<length(DHT22_data)== 1
   DHT22_data = DHT22_data(1:length(SDS_Data),:);
elseif  length(SDS_Data)>length(DHT22_data)==1
   SDS_Data = SDS_Data(1:length(DHT22_data),:);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%Sorting low conspicuous values for the readings    
if (min(SDS_Data(:,2))<=1.5) or (min(SDS_Data(:,3))<=0.5);
    data_lowPM = SDS_Data(SDS_Data(:,2) <=1.5, :);
    data_normal = SDS_Data(SDS_Data(:,2)>1.5,:);
%%%%%Finding correlations between observed measurements     
    disp("Data Statistics")
    Corr_all_SDS_Data = corr(SDS_Data(:,2),SDS_Data(:,3))
    Corr_P1_P2_Normal_SDS_Data= corr(data_normal(:,2),data_normal(:,3))
    CorrP1_P2_LowPM = corr(data_lowPM(:,2),data_lowPM(:,3))
    Corr_Temp_P1 = corr(SDS_Data(:,2),DHT22_data(:,2))
    Corr_Temp_P2 = corr(SDS_Data(:,3),DHT22_data(:,2))
    Corr_Humidity_P1 = corr(SDS_Data(:,2),DHT22_data(:,3))
    Corr_Humidity_P2 = corr(SDS_Data(:,3),DHT22_data(:,3))
%%%%%General statistics; minima, maxima, means, Standard Deviations      
    disp("P1")
    minimum_P1 = min(SDS_Data(:,2))
    maximum_P1 = max(SDS_Data(:,2))
    mean_P1 = mean(SDS_Data(:,2))
    Std_Dev_P1 = std(SDS_Data(:,2))
    disp("P2")
    minimum_P2 = min(SDS_Data(:,3))
    maximum_P2 = max(SDS_Data(:,3))
    mean_P2 = mean(SDS_Data(:,3))
    Std_Dev_P2 = std(SDS_Data(:,3))
else
    disp("Data Statistics");
%%%%%Finding correlations between observed measurements       
    Corr_P1_P2 = corr(SDS_Data(:,2),SDS_Data(:,3))
    Corr_Temp_P1 = corr(SDS_Data(:,2),DHT22_data(:,2))
    Corr_Temp_P2 = corr(SDS_Data(:,3),DHT22_data(:,2))
    Corr_Humidity_P1 = corr(SDS_Data(:,2),DHT22_data(:,3))
    Corr_Humidity_P2 = corr(SDS_Data(:,3),DHT22_data(:,3))
%%%%%General statistics; minima, maxima, means, Standard Deviations         
    minimum_P1 = min(SDS_Data(:,2))
    maximum_P1 = max(SDS_Data(:,2)) 
    mean_P1 = mean(SDS_Data(:,2))
    Std_Dev_P1 = std(SDS_Data(:,2))
    disp("P2")
    minimum_P2 = min(SDS_Data(:,3))
    maximum_P2 = max(SDS_Data(:,3))
    mean_P2 = mean(SDS_Data(:,3))
    Std_Dev_P2 = std(SDS_Data(:,3)) 
end 
    
%%%%% Plotting the graphs for Data observed
    plot(DHT22_data(:,2),"g;Temperature;",DHT22_data(:,3),"c;Humidity;")
   ylabel('Temperature in degrees celsius and Humidity as a percentage')
   xlabel('Entry Number')

%  plot(SDS_Data(:,2),"k;P1 Concentration Values;",SDS_Data(:,3),"r;P2 Concentration Values;");
%  xlabel('Entry Number');
%  ylabel('PM Concentration in Micrograms per cubic metre');